# 1. Imports
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from fpdf import FPDF

# 2. Read Data
df = pd.read_csv("../03-Data cleaning/clean_data.csv")

# 3. Dataset Information
n_rows, n_cols = df.shape
n_players = df["personId"].nunique()
n_games = df["gameId"].nunique()
n_teams = df["playerteamName"].nunique()
first_season = df["season_label"].min()
last_season = df["season_label"].max()

# 4. Summary Statistics
stat_cols = ["numMinutes", "points", "assists", "reboundsTotal", "steals", "blocks", "turnovers"]
for col in stat_cols:
    df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)
summary_stats = df[stat_cols].describe().round(2)
summary_stats = summary_stats.loc[["mean", "std", "min", "max"]]

# 5. Visualizations

# Visualization 1: Distribution of points scored per game
plt.figure(figsize=(6, 4))
sns.histplot(df["points"], bins=30, color="steelblue")
plt.title("Distribution of Points per Game")
plt.xlabel("Points")
plt.ylabel("Count")
plt.tight_layout()
plt.savefig("viz1_points_distribution.png")
plt.close()

# Visualization 2: Average points by starting position
position_points = df[df["startingPosition"] != "Unknown"].groupby("startingPosition")["points"].mean().sort_values(ascending=False)
plt.figure(figsize=(6, 4))
sns.barplot(x=position_points.index, y=position_points.values, color="darkorange")
plt.title("Average Points by Starting Position")
plt.xlabel("Starting Position")
plt.ylabel("Average Points")
plt.tight_layout()
plt.savefig("viz2_avg_points_by_position.png")
plt.close()

# Visualization 3: Relationship between minutes played and points scored
plt.figure(figsize=(6, 4))
sns.scatterplot(x=df["numMinutes"], y=df["points"], alpha=0.2)
plt.title("Minutes Played vs Points Scored")
plt.xlabel("Minutes Played")
plt.ylabel("Points")
plt.tight_layout()
plt.savefig("viz3_minutes_vs_points.png")
plt.close()

# Visualization 4: Correlation among key box-score stats
plt.figure(figsize=(6, 5))
sns.heatmap(df[stat_cols].corr().round(2), annot=True, cmap="coolwarm")
plt.title("Correlation of Box-Score Stats")
plt.tight_layout()
plt.savefig("viz4_correlation_heatmap.png")
plt.close()

# 6. Key Analytical Findings
avg_points = round(df["points"].mean(), 2)
corr_minutes_points = round(df["numMinutes"].corr(df["points"]), 2)
home_win_rate = round(df.loc[df["home"] == True, "win"].mean() * 100, 1)
away_win_rate = round(df.loc[df["home"] == False, "win"].mean() * 100, 1)
best_position = position_points.index[0]
best_position_avg = round(position_points.iloc[0], 2)

# 7. Create PDF
pdf = FPDF()
pdf.add_page()

# 8. Project Title
pdf.set_font("Helvetica", "B", 18)
pdf.cell(0, 12, "NBA Player Game Statistics - Automated Report", ln=True, align="C")
pdf.ln(5)

# 9. Dataset Summary
pdf.set_font("Helvetica", "B", 14)
pdf.cell(0, 10, "Dataset Summary", ln=True)
pdf.set_font("Helvetica", "", 11)
pdf.multi_cell(0, 8,
    "This dataset contains " + str(n_rows) + " observations and " + str(n_cols) + " variables.\n"
    "It covers " + str(n_games) + " games, " + str(n_players) + " unique players, and " + str(n_teams) + " teams.\n"
    "Seasons range from " + str(first_season) + " to " + str(last_season) + "."
)
pdf.ln(3)

# 10. Summary Statistics Table
pdf.set_font("Helvetica", "B", 14)
pdf.cell(0, 10, "Summary Statistics", ln=True)
pdf.set_font("Helvetica", "B", 10)
col_width = 25
pdf.cell(30, 8, "Stat", border=1)
for col in stat_cols:
    pdf.cell(col_width, 8, col[:12], border=1)
pdf.ln()
pdf.set_font("Helvetica", "", 10)
for stat_name in summary_stats.index:
    pdf.cell(30, 8, str(stat_name), border=1)
    for col in stat_cols:
        pdf.cell(col_width, 8, str(summary_stats.loc[stat_name, col]), border=1)
    pdf.ln()
pdf.ln(5)

# 11. Visualizations
pdf.set_font("Helvetica", "B", 14)
pdf.cell(0, 10, "Visualizations", ln=True)
pdf.image("viz1_points_distribution.png", w=170)
pdf.ln(3)
pdf.image("viz2_avg_points_by_position.png", w=170)
pdf.add_page()
pdf.image("viz3_minutes_vs_points.png", w=170)
pdf.ln(3)
pdf.image("viz4_correlation_heatmap.png", w=150)
pdf.ln(5)

# 12. Key Analytical Findings
pdf.set_font("Helvetica", "B", 14)
pdf.cell(0, 10, "Key Analytical Findings", ln=True)
pdf.set_font("Helvetica", "", 11)
pdf.multi_cell(0, 8,
    "- The average points scored per player per game is " + str(avg_points) + ".\n"
    "- Minutes played and points scored have a correlation of " + str(corr_minutes_points) + ".\n"
    "- Win rate when playing at home is " + str(home_win_rate) + "%, compared to " + str(away_win_rate) + "% away.\n"
    "- The starting position with the highest average points is " + str(best_position) + " with " + str(best_position_avg) + " points per game."
)

# 13. Save Report
pdf.output("project_report.pdf")

print("Report saved to project_report.pdf")
